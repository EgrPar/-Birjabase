﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Биржа_труда
{
    /// <summary>
    /// Логика взаимодействия для VacancyDetailsWindow.xaml
    /// </summary>
    public partial class VacancyDetailsWindow : Window
    {
        public VacancyDetailsWindow(Vacancies vacancy)
        {
            InitializeComponent();
            DataContext = vacancy; // Устанавливаем вакансию как контекст данных
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что вакансия передана в DataContext
            if (DataContext is Vacancies selectedVacancy)
            {
                var applicationWindow = new ApplicationWindow(selectedVacancy)
                {
                    Owner = this // Устанавливаем текущее окно как владельца
                };

                applicationWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Не удалось получить данные о вакансии",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
