﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Биржа_труда
{
    /// <summary>
    /// Логика взаимодействия для ApplicationWindow.xaml
    /// </summary>
    public partial class ApplicationWindow : Window
    {
        private Vacancies _selectedVacancy;
        

        public ApplicationWindow(Vacancies vacancy)
        {
            InitializeComponent();
            _selectedVacancy = vacancy;
            DataContext = this;
        }

        public Vacancies SelectedVacancy => _selectedVacancy;

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var context = new BirjaBaseEntities())
                {
                    // Создаем нового соискателя
                    var seeker = new JobSeekers
                    {
                        FullName = FullNameBox.Text,
                        BirthDate = BirthDatePicker.SelectedDate.Value,
                        Email = EmailBox.Text,
                        Phone = PhoneBox.Text,
                        Resume = ResumeBox.Text
                    };

                    // Создаем заявку
                    var application = new Applications
                    {
                        SeekerID = seeker.SeekerID,
                        VacancyID = _selectedVacancy.VacancyID,
                        ApplicationDate = DateTime.Now,
                        Status = "Новая"
                    };
                    context.JobSeekers.Add(seeker);
                    context.Applications.Add(application);
                    context.SaveChanges();
                }

                MessageBox.Show("Заявка успешно отправлена!", "Успех",
                             MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении заявки: {ex.Message}",
                             "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(FullNameBox.Text))
            {
                MessageBox.Show("Введите ФИО соискателя", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (BirthDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Укажите дату рождения", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(EmailBox.Text) ||
                !EmailBox.Text.Contains("@"))
            {
                MessageBox.Show("Введите корректный email", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(PhoneBox.Text))
            {
                MessageBox.Show("Введите телефон", "Ошибка",
                             MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
