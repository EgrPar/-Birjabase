﻿using System;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace Биржа_труда
{
    public partial class AdmPage : Page
    {
        private BirjaBaseEntities _context = new BirjaBaseEntities();

        public AdmPage()
        {
            InitializeComponent();
            LoadApplications();

        }

        private void LoadApplications()
        {
            try
            {
                using (var context = new BirjaBaseEntities())
                {
                    context.Configuration.LazyLoadingEnabled = false;

                    var applications = context.Applications
                        .Include(a => a.JobSeekers)
                        .Include(a => a.Vacancies)
                        .Include(a => a.Vacancies.Employers) // Критически важно!
                        .OrderByDescending(a => a.ApplicationDate)
                        .ToList();

                    ApplicationsDataGrid.ItemsSource = applications;
                    UpdateStats(applications.Count);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }
        private void UpdateStats(int count)
        {
            Dispatcher.Invoke(() =>
            {
                if (count == 0)
                {
                    StatsText.Text = "Нет заявок";
                    StatsText.Foreground = Brushes.Red;
                }
                else
                {
                    StatsText.Text = $"Заявок: {count}";
                    StatsText.Foreground = Brushes.Green;
                }
            });
        }
        private void AddVacancy_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var context = new BirjaBaseEntities())
                {
                    // Создаем новую вакансию с минимально необходимыми данными
                    var newVacancy = new Vacancies
                    {
                        Position = "Новая вакансия",
                        PostDate = DateTime.Now,
                        EmployerID = context.Employers.FirstOrDefault()?.EmployerID ?? 0 // Берем первого работодателя
                    };

                    var vacancyWindow = new VacancyEditWindow(newVacancy)
                    {
                        Owner = Window.GetWindow(this)
                    };

                    if (vacancyWindow.ShowDialog() == true)
                    {
                        LoadApplications(); // Обновляем список
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания вакансии: {ex.Message}");
            }
        }

        private void EditVacancy_Click(object sender, RoutedEventArgs e)
        {
            var selectWindow = new VacancySelectWindow { Owner = Window.GetWindow(this) };

            if (selectWindow.ShowDialog() == true && selectWindow.SelectedVacancy != null)
            {
                var editWindow = new VacancyEditWindow(selectWindow.SelectedVacancy)
                {
                    Owner = Window.GetWindow(this)
                };

                if (editWindow.ShowDialog() == true)
                {
                    RefreshData();
                }
            }
        }
        private void EditVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            var selectWindow = new VacancySelectWindow { Owner = Window.GetWindow(this) };

            if (selectWindow.ShowDialog() == true && selectWindow.SelectedVacancy != null)
            {
                var editWindow = new VacancyEditWindow(selectWindow.SelectedVacancy)
                {
                    Owner = Window.GetWindow(this)
                };

                if (editWindow.ShowDialog() == true)
                {
                    // Обновляем данные после редактирования
                    RefreshData();
                }
            }
        }

        private void RefreshData()
        {
            using (var context = new BirjaBaseEntities())
            {
                ApplicationsDataGrid.ItemsSource = context.Applications
                    .Include(a => a.JobSeekers)
                    .Include(a => a.Vacancies)
                    .ToList();
            }
        }

        private void ExitBut_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Вы точно хотите выйти?",
                "Подтверждение выхода",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Manager.MainFrame.Navigate(new LoginPage());
            }
        }

        private void ExportToExcel()
        {
            try
            {
                var excelApp = new Excel.Application();
                excelApp.Visible = true;
                Excel.Workbook workbook = excelApp.Workbooks.Add();
                Excel._Worksheet worksheet = workbook.ActiveSheet;

                // Заголовки столбцов
                worksheet.Cells[1, 1] = "ID заявки";
                worksheet.Cells[1, 2] = "Соискатель";
                worksheet.Cells[1, 3] = "Вакансия";
                worksheet.Cells[1, 4] = "Компания";
                worksheet.Cells[1, 5] = "Дата заявки";
                worksheet.Cells[1, 6] = "Статус";
                worksheet.Cells[1, 7] = "Телефон";
                worksheet.Cells[1, 8] = "Email";

                // Данные
                var applications = _context.Applications
                    .Include("JobSeekers")
                    .Include("Vacancies")
                    .Include("Vacancies.Employers")
                    .ToList();

                int row = 2;
                foreach (var app in applications)
                {
                    worksheet.Cells[row, 1] = app.ApplicationID;
                    worksheet.Cells[row, 2] = app.JobSeekers?.FullName;
                    worksheet.Cells[row, 3] = app.Vacancies?.Position;
                    worksheet.Cells[row, 4] = app.Vacancies?.Employers?.CompanyName;
                    worksheet.Cells[row, 5] = app.ApplicationDate.ToString("dd.MM.yyyy");
                    worksheet.Cells[row, 6] = app.Status;
                    worksheet.Cells[row, 7] = app.JobSeekers?.Phone;
                    worksheet.Cells[row, 8] = app.JobSeekers?.Email;
                    row++;
                }

                // Автоподбор ширины столбцов
                worksheet.Columns.AutoFit();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка экспорта в Excel: {ex.Message}");
            }
        }

        private void ExportToWord()
        {
            try
            {
                var wordApp = new Word.Application();
                var document = wordApp.Documents.Add();
                wordApp.Visible = true;

                // Заголовок документа
                Word.Paragraph title = document.Content.Paragraphs.Add();
                title.Range.Text = "Отчет по заявкам";
                title.Range.Font.Bold = 1;
                title.Range.Font.Size = 16;
                title.Range.InsertParagraphAfter();

                // Данные для таблицы
                var applications = _context.Applications
                    .Include("JobSeekers")
                    .Include("Vacancies")
                    .Include("Vacancies.Employers")
                    .ToList();

                // Создание таблицы
                Word.Table table = document.Tables.Add(
                    document.Range(document.Content.End - 1, document.Content.End - 1),
                    applications.Count + 1,  // +1 для заголовков
                    6);  // Количество столбцов

                table.Borders.Enable = 1;
                table.Rows[1].Range.Bold = 1;

                // Заголовки столбцов
                table.Cell(1, 1).Range.Text = "Соискатель";
                table.Cell(1, 2).Range.Text = "Вакансия";
                table.Cell(1, 3).Range.Text = "Компания";
                table.Cell(1, 4).Range.Text = "Дата";
                table.Cell(1, 5).Range.Text = "Статус";
                table.Cell(1, 6).Range.Text = "Телефон";

                // Заполнение таблицы
                for (int i = 0; i < applications.Count; i++)
                {
                    var app = applications[i];
                    table.Cell(i + 2, 1).Range.Text = app.JobSeekers?.FullName ?? "";
                    table.Cell(i + 2, 2).Range.Text = app.Vacancies?.Position ?? "";
                    table.Cell(i + 2, 3).Range.Text = app.Vacancies?.Employers?.CompanyName ?? "";
                    table.Cell(i + 2, 4).Range.Text = app.ApplicationDate.ToString("dd.MM.yyyy");
                    table.Cell(i + 2, 5).Range.Text = app.Status ?? "";
                    table.Cell(i + 2, 6).Range.Text = app.JobSeekers?.Phone ?? "";
                }

                // Автоподбор ширины столбцов
                table.Columns.AutoFit();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка экспорта в Word: {ex.Message}");
            }
        }

        private void ExcelBut_Click(object sender, RoutedEventArgs e)
        {
            ExportToExcel();
        }

        private void WordBut_Click(object sender, RoutedEventArgs e)
        {
            ExportToWord();
        }

        private void RefreshBut_Click(object sender, RoutedEventArgs e)
        {
            LoadApplications();
        }

    }
}