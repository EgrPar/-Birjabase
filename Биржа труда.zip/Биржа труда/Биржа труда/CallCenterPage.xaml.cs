﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Биржа_труда
{
    public partial class CallCenterPage : Page
    {
        private BirjaBaseEntities _context = new BirjaBaseEntities();

        public CallCenterPage()
        {
            InitializeComponent();
            InitializeFilters();
            LoadApplications();
        }

        private void InitializeFilters()
        {
            StatusFilter.ItemsSource = new List<FilterItem>
            {
                new FilterItem { Value = null, Display = "Все статусы" },
                new FilterItem { Value = "Новая", Display = "Новые заявки" },
                new FilterItem { Value = "В обработке", Display = "В обработке" },
                new FilterItem { Value = "Приглашен на собеседование", Display = "На собеседовании" },
                new FilterItem { Value = "Отклонена", Display = "Отклоненные" },
                new FilterItem { Value = "Принята", Display = "Принятые" }
            };
            StatusFilter.DisplayMemberPath = "Display";
            StatusFilter.SelectedValuePath = "Value";
            StatusFilter.SelectedIndex = 0;
        }

        private void LoadApplications(string statusFilter = null)
        {
            try
            {
                _context = new BirjaBaseEntities(); // Пересоздаем контекст

                var query = _context.Applications
                    .Include("JobSeekers")
                    .Include("Vacancies")
                    .Include("Vacancies.Employers")
                    .AsQueryable();

                if (!string.IsNullOrEmpty(statusFilter))
                {
                    query = query.Where(a => a.Status == statusFilter);
                }

                var applications = query
                    .OrderByDescending(a => a.ApplicationDate)
                    .ToList();

                ApplicationsGrid.ItemsSource = applications;
                StatsText.Text = $"Найдено заявок: {applications.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}\n\n{ex.InnerException?.Message}");
            }
        }

        private void StatusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ApplicationsGrid.SelectedItem is Applications selectedApp &&
                sender is ComboBox comboBox &&
                comboBox.SelectedItem != null)
            {
                try
                {
                    selectedApp.Status = comboBox.SelectedItem.ToString();
                    _context.SaveChanges();
                    LoadApplications(StatusFilter.SelectedValue as string); // Обновляем данные
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения: {ex.Message}");
                    _context.Entry(selectedApp).Reload();
                }
            }
        }

        private void StatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedStatus = StatusFilter.SelectedValue as string;
            LoadApplications(selectedStatus);
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadApplications(StatusFilter.SelectedValue as string);
        }

        private void ExtBut_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new LoginPage());
        }
    }

    public class FilterItem
    {
        public string Value { get; set; }
        public string Display { get; set; }
    }

}