﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Биржа_труда
{
    /// <summary>
    /// Логика взаимодействия для PassPage.xaml
    /// </summary>
    public partial class PassPage : Page
    {
        private int failedAttempts = 0;
        private const int MaxFailedAttempts = 3;
        private bool captchaVerified = false;
        public PassPage()
        {
            InitializeComponent();

        }
        private void PasswordBtn_Click(object sender, RoutedEventArgs e)
        {
            var Password = PasswordBox.Password.Trim();
            var Login = Manager.UserLogin;
            var user = BirjaBaseEntities.GetContext().Users.AsEnumerable().FirstOrDefault(u => u.login == Login);

            if (string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Введите пароль!");
                return;
            }

            if (user == null || user.pass.ToString() != Password)
            {
                failedAttempts++;
                if (failedAttempts >= MaxFailedAttempts)
                {
                    ShowCaptcha();
                }
                MessageBox.Show("Неправильный пароль");
                return;
            }

            ShowCaptcha();

        }
        private void ShowCaptcha()
        {
            GenerateNewCaptcha();
            CaptchaBorder.Visibility = Visibility.Visible;
            PasswordBtn.IsEnabled = false;
        }

        private void HideCaptcha()
        {
            CaptchaBorder.Visibility = Visibility.Collapsed;
            PasswordBtn.IsEnabled = true;
            captchaVerified = true;
        }

        private void GenerateNewCaptcha()
        {

            var random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            CaptchaText.Text = new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());
            CaptchaInput.Text = "";
        }

        private void RefreshCaptchaBtn_Click(object sender, RoutedEventArgs e)
        {
            GenerateNewCaptcha();
        }

        private void CaptchaSubmitBtn_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaInput.Text.Trim().Equals(CaptchaText.Text, StringComparison.OrdinalIgnoreCase))
            {
                var Password = PasswordBox.Password.Trim();
                var user = BirjaBaseEntities.GetContext().Users.AsEnumerable().FirstOrDefault(u => u.pass.ToString() == Password);

                if (user != null && user.pass.ToString() == Password)
                {
                    CompleteLogin();
                }
                else
                {
                    MessageBox.Show("Пароль неверный");
                    HideCaptcha();
                }
            }
            else
            {
                MessageBox.Show("Неверная капча. Попробуйте снова.");
                GenerateNewCaptcha();
            }
        }

        private void CompleteLogin()
        {
            // Reset attempts for next time
            failedAttempts = 0;
            captchaVerified = false;
            var Login = Manager.UserLogin;
            var user = BirjaBaseEntities.GetContext().Users.AsEnumerable().FirstOrDefault(u => u.login == Login);
            string role = user.role;
            switch (role)
            {
                case "admin":
                    Manager.MainFrame.Navigate(new AdmPage());
                    break;
                case "emp":
                    Manager.MainFrame.Navigate(new EmpPage());
                    break;
                case "call":
                    Manager.MainFrame.Navigate(new CallCenterPage());
                    break;
            }
        }
    }
}
