﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Биржа_труда
{
    internal class Manager
    {
        public static Frame MainFrame { get; set; }
        public static string UserLogin { get; set; }
        public static void CompleteLogin(string Login)
        {
            UserLogin = Login;
        }
    }
}
