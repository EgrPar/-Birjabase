﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;

namespace Биржа_труда
{
    public partial class VacancySelectWindow : Window
    {
        public Vacancies SelectedVacancy { get; private set; }

        public VacancySelectWindow()
        {
            InitializeComponent();
            LoadVacancies();
        }

        private void LoadVacancies()
        {
            try
            {
                using (var context = new BirjaBaseEntities())
                {
                    VacanciesDataGrid.ItemsSource = context.Vacancies
                        .Include(v => v.Employers)
                        .OrderByDescending(v => v.PostDate)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            if (VacanciesDataGrid.SelectedItem is Vacancies selected)
            {
                SelectedVacancy = selected;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Выберите вакансию!");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (VacanciesDataGrid.SelectedItem is Vacancies selected)
            {
                var result = MessageBox.Show(
                    $"Вы точно хотите удалить вакансию '{selected.Position}'?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (var context = new BirjaBaseEntities())
                        {
                            // Загружаем вакансию с привязанными заявками
                            var vacancyToDelete = context.Vacancies
                                .Include(v => v.Applications)
                                .FirstOrDefault(v => v.VacancyID == selected.VacancyID);

                            if (vacancyToDelete != null)
                            {
                                // Удаляем связанные заявки сначала
                                context.Applications.RemoveRange(vacancyToDelete.Applications);

                                // Затем удаляем саму вакансию
                                context.Vacancies.Remove(vacancyToDelete);

                                context.SaveChanges();
                                LoadVacancies();
                                MessageBox.Show("Вакансия успешно удалена!");
                            }
                        }
                    }
                    catch (System.Data.Entity.Infrastructure.DbUpdateException dbEx)
                    {
                        string errorMessage = "Не удалось удалить вакансию.\n";

                        if (dbEx.InnerException?.InnerException is System.Data.SqlClient.SqlException sqlEx)
                        {
                            switch (sqlEx.Number)
                            {
                                case 547:
                                    errorMessage += "Существуют связанные записи в других таблицах.";
                                    break;
                                default:
                                    errorMessage += sqlEx.Message;
                                    break;
                            }
                        }
                        else
                        {
                            errorMessage += dbEx.Message;
                        }

                        MessageBox.Show(errorMessage, "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите вакансию для удаления!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}