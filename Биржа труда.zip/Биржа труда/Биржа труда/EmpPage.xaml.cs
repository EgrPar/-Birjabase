﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using System.Runtime.Remoting.Contexts;

namespace Биржа_труда
{
    /// <summary>
    /// Логика взаимодействия для EmpPage.xaml
    /// </summary>

    public partial class EmpPage : Page
    {
        public EmpPage()
        {
            InitializeComponent();
            InitializeSalaryFilter();
            LoadJobs();
        }

        private void InitializeSalaryFilter()
        {
            SalaryFilter.SelectedIndex = 0;
        }

        private void LoadJobs(string searchText = null)
        {
            try
            {
                // Не используем Items.Clear() при установленном ItemsSource
                // Вместо этого просто обновляем ItemsSource

                IQueryable<Vacancies> query = BirjaBaseEntities.GetContext().Vacancies
                    .Include(v => v.Employers);

                if (!string.IsNullOrEmpty(searchText))
                {
                    query = query.Where(v =>
                        v.Position.Contains(searchText) ||
                        v.Description.Contains(searchText) ||
                        v.Requirements.Contains(searchText) ||
                        v.Employers.CompanyName.Contains(searchText));
                }

                if (SalaryFilter.SelectedItem is ComboBoxItem selectedItem &&
                    decimal.TryParse(selectedItem.Tag?.ToString(), out decimal minSalary) &&
                    minSalary > 0)
                {
                    query = query.Where(v => v.Salary >= minSalary);
                }

                // Создаем новый список для ItemsSource
                var jobs = query.OrderByDescending(j => j.PostDate).ToList();
                JobsListView.ItemsSource = jobs;
                StatsText.Text = $"Найдено вакансий: {jobs.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки вакансий: {ex.Message}");
                JobsListView.ItemsSource = null; // Сбрасываем ItemsSource при ошибке
            }
        }

        private void ApplyFilters()
        {
            LoadJobs(SearchBox.Text);

        }

        // Остальные методы остаются без изменений
        private void SearchBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) ApplyFilters();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = "";
            SalaryFilter.SelectedIndex = 0;
            ApplyFilters();
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (JobsListView.SelectedItem is Vacancies selectedJob)
            {
                if (JobsListView.SelectedItem is Vacancies selectedVacancy)
                {
                    var detailsWindow = new VacancyDetailsWindow(selectedVacancy)
                    {
                        Owner = Window.GetWindow(this)
                    };
                    detailsWindow.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите вакансию",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void JobsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (JobsListView.SelectedItem is Vacancies selectedVacancy)
            {
                var detailsWindow = new VacancyDetailsWindow(selectedVacancy)
                {
                    Owner = Window.GetWindow(this)
                };
                detailsWindow.ShowDialog();
            }
        }

        private void SalaryFilter_Changed(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }
        private void ExtBut_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new LoginPage());
        }
    }
}
