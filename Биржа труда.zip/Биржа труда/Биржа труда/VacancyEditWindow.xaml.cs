﻿using System;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Linq;
using System.Text;
using System.Windows;

namespace Биржа_труда
{
    public partial class VacancyEditWindow : Window
    {
        private readonly BirjaBaseEntities _context = new BirjaBaseEntities();
        public Vacancies Vacancy { get; private set; }

        public VacancyEditWindow(Vacancies vacancy)
        {
            InitializeComponent();

            try
            {
                Vacancy = _context.Vacancies.Find(vacancy.VacancyID) ?? vacancy;
                DataContext = Vacancy;
                LoadEmployers();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
                Close();
            }
        }

        private void LoadEmployers()
        {
            try
            {
                EmployerComboBox.ItemsSource = _context.Employers.ToList();
                EmployerComboBox.DisplayMemberPath = "CompanyName";
                EmployerComboBox.SelectedValuePath = "EmployerID";
                EmployerComboBox.SelectedValue = Vacancy.EmployerID;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки работодателей: {ex.Message}");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var context = new BirjaBaseEntities())
                {
                    // Для новой вакансии
                    if (Vacancy.VacancyID == 0)
                    {
                        // Создаем новый объект для избежания проблем с отслеживанием
                        var newVacancy = new Vacancies
                        {
                            Position = Vacancy.Position,
                            Description = Vacancy.Description,
                            Requirements = Vacancy.Requirements,
                            Salary = Vacancy.Salary,
                            EmploymentType = Vacancy.EmploymentType,
                            PostDate = DateTime.Now,
                            EmployerID = (int)EmployerComboBox.SelectedValue
                        };

                        context.Vacancies.Add(newVacancy);
                    }
                    else // Для существующей вакансии
                    {
                        var existingVacancy = context.Vacancies.Find(Vacancy.VacancyID);
                        if (existingVacancy != null)
                        {
                            // Копируем измененные свойства
                            existingVacancy.Position = Vacancy.Position;
                            existingVacancy.Description = Vacancy.Description;
                            existingVacancy.Requirements = Vacancy.Requirements;
                            existingVacancy.Salary = Vacancy.Salary;
                            existingVacancy.EmploymentType = Vacancy.EmploymentType;
                            existingVacancy.EmployerID = (int)EmployerComboBox.SelectedValue;
                        }
                    }

                    context.SaveChanges();
                    DialogResult = true;
                    Close();
                }
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                ShowValidationErrors(ex);
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {
                ShowDatabaseErrors(ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неожиданная ошибка: {ex.Message}");
            }
        }

        private void ShowValidationErrors(System.Data.Entity.Validation.DbEntityValidationException ex)
        {
            var errorMessages = new StringBuilder();
            foreach (var validationErrors in ex.EntityValidationErrors)
            {
                foreach (var validationError in validationErrors.ValidationErrors)
                {
                    errorMessages.AppendLine($"• {validationError.PropertyName}: {validationError.ErrorMessage}");
                }
            }
            MessageBox.Show($"Ошибки валидации:\n{errorMessages}", "Ошибка сохранения");
        }

        private void ShowDatabaseErrors(System.Data.Entity.Infrastructure.DbUpdateException ex)
        {
            var errorMessage = new StringBuilder("Ошибка базы данных:\n");

            if (ex.InnerException is UpdateException updateEx)
            {
                if (updateEx.InnerException is System.Data.SqlClient.SqlException sqlEx)
                {
                    switch (sqlEx.Number)
                    {
                        case 547:
                            errorMessage.AppendLine("Ошибка связанных данных. Проверьте:");
                            errorMessage.AppendLine("- Существует ли указанный работодатель");
                            errorMessage.AppendLine("- Нет ли связанных заявок");
                            break;
                        case 2601:
                        case 2627:
                            errorMessage.AppendLine("Такая вакансия уже существует");
                            break;
                        default:
                            errorMessage.AppendLine(sqlEx.Message);
                            break;
                    }
                }
                else
                {
                    errorMessage.AppendLine(updateEx.Message);
                }
            }
            else
            {
                errorMessage.AppendLine(ex.Message);
            }

            MessageBox.Show(errorMessage.ToString(), "Ошибка сохранения");
        }
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(Vacancy.Position))
            {
                MessageBox.Show("Название должности обязательно!");
                return false;
            }

            if (EmployerComboBox.SelectedValue == null)
            {
                MessageBox.Show("Выберите работодателя!");
                return false;
            }

            if (Vacancy.Salary < 0)
            {
                MessageBox.Show("Зарплата не может быть отрицательной!");
                return false;
            }

            return true;
        }



        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}